# 🧠 Clarity Engine Project Meta (Internal)

This directory contains the modular, memory-backed documentation and task system that supports the Clarity Kernel runtime.

It exists to do the following:
- Track the execution and blessing of all `.md` and `.json` files
- Allow documents to expand safely past 250 lines using `DocExpansionRouter.json`
- Link every document to its originating agent, validation schema, memory snippet, and blessed version
- Route all document rewrites and expansion triggers through the `span_trace.log`

---

## 🧱 What This Is

This is a **document execution layer** for your kernel.  
It is not static docs. It is not fluff. It is not filler.

Each file in this directory is a **blessable, expandable, traceable output** of your runtime — and must follow the tone, structure, and clarity standards enforced by your agents.

---

## 🔁 Core Runtime Ties

These are the runtime elements this meta system interacts with:

- `runAgent.js` → launches agents that suggest or rewrite docs
- `validateAllAgents.js` → ensures schema and tone compliance
- `blessAgent.js` → final blessing and export to `/outputs/blessed/`
- `ParsedMemoryMap.json` → logs memory parsed from chat, commands, or strategy
- `OrchestrationMap.json` → maps agents to file responsibilities
- `DocExpansionRouter.json` → expands any file over 250 lines into subdocs
- `span_trace.log` → logs every document rewrite, expansion, and blessing event

---

## 📑 Document Lifecycle

Every document here:
- Starts as a draft, generated or hand-written
- Gets parsed by `MemoryParserAgent.js` and added to `ParsedMemoryMap.json`
- May be expanded into subdocs once it exceeds 250 lines
- Is validated by the `Validator` agent
- Is routed through `DocRewriterAgent.js` for memory-context editing
- Is logged in `span_trace.log` when changed
- Is blessed only after passing structure, tone, and schema checks

---

## 📂 Folder Overview

| Folder | Purpose |
|--------|---------|
| `/plans/` | All execution specs: ACTION_PLAN, FINALIZATION_PLAN, etc. |
| `/task_logs/` | Logged agent tasks and doc edits |
| `/reports/` | Validation coverage, test logs, telemetry |
| `/logs/` | Run history for agents, memory trace, and execution errors |
| `/versioning/` | Tracks all blessed versions and document hashes |

---

## 📎 Expansion Rule

No document in this folder should exceed 250 lines.  
If it does, run:
```bash
node validateDocLength.js
```
Then update `DocExpansionRouter.json` and bless the new subdoc.

---

## ✅ Output Example

Once blessed, a document should:
- Be listed in `documentation_versions.json`
- Include links to its subdocs (if expanded)
- Reference the memory that triggered its last rewrite
- Be stored in `/outputs/blessed/` and never overwritten manually

---

## 🧠 This System Lets You...

- Collaborate with agents like they’re co-authors
- Expand documentation with traceable memory
- Prevent output drift, recursion, or hallucinated edits
- Build an infrastructure-grade clarity kernel

This is not a knowledge base. It’s a clarity execution mesh.

Welcome to the internal layer of your runtime.