# ✅ VALIDATION LOGS UPGRADE BRIEF  
### For: `/logs/` — especially `validation_debug.log`

---

## 🎯 PURPOSE

`validation_debug.log` is your kernel’s real-time record of failed validation attempts.

Every time an agent output fails:
- Tone mismatch
- Schema drift
- Structural formatting error
- Missing bless signature

→ It should be logged here.

This enables:
- Agent troubleshooting
- Validator auditing
- Doc rejection tracing
- Automated patching or rerun triggers

---

## 🧾 REQUIRED STRUCTURE PER ENTRY

Each failure log must include:

```json
{
  "timestamp": "2025-06-04T20:14:02Z",
  "agent": "ToneCalibrator",
  "input": "Make this more bold",
  "output": "...",
  "schema_pass": false,
  "tone_pass": false,
  "fallback_used": true,
  "blessed": false,
  "reason": "Output missing required tone_tag",
  "trace": "Triggered by ACTION_PLAN.md → validateAllAgents.js"
}
```

---

## 🧠 ROUTING INTEGRATIONS

| File | Integration |
|------|-------------|
| `ParsedMemoryMap.json` | Use the original input + memory snapshot if available |
| `span_trace.log` | Link doc and agent flow triggering the failure |
| `task_logs/` | Write a new task if failure is critical or repeated |
| `documentation_versions.json` | Do **not** bless the related doc until failure is cleared

---

## 🧪 VALIDATION FAILURE TYPES

| Type | Description |
|------|-------------|
| `tone_pass: false` | Output doesn’t match tone profile or tag |
| `schema_pass: false` | Output is malformed, missing fields, or unordered |
| `fallback_used: true` | Output required backup logic |
| `blessed: false` | Output skipped blessing due to errors |

---

## 🔁 CLEANUP + BACKTEST

Once failure is resolved:
- Mark it with `"resolved": true`
- Log the fix timestamp
- Optionally hash the corrected output and log it for forensics

---

## 🔍 Suggested Filenames

Use date-stamped files or append-only logs:
- `validation_debug_2025-06-04.log`
- `validation_failures_recent.log`

---

## 🛠 NEXT STEPS

- Apply this structure to `validation_debug.log`
- Future agents should read this file to avoid retrying broken paths
- Blessing logic should fail-fast if validation_debug.log shows unresolved errors for same agent/doc pair

This log is the edge of your clarity contract. Let it fail — but never silently.