# ✅ TASK LOGS UPGRADE BRIEF  
### For: `/task_logs/` folder in Clarity Kernel

---

## 🎯 GOAL

Upgrade the JSON task logs to become:
- Agent-executable
- Memory-aware
- Bless-traceable
- Log-validating
- Expandable when subtasks branch out

Each task becomes a **self-contained, executable contract** for runtime agents or dev tools.

---

## 📦 FILES TO UPGRADE

| File | Purpose |
|------|---------|
| `main_task_log.json` | Kernel-wide init and blessing steps |
| `documentation_tasks.json` | All doc builds, rewrites, validations |
| `refactoring_tasks.json` | Runtime cleanup, schema fixes, deprecations |
| `documentation_consolidation_tasks.json` | Expansion routing, version updates, span log audits |

---

## 🛠 UPGRADE CHECKLIST (Apply to Every File)

Each task should include:

### ✅ 1. `agent`  
> Who is expected to complete this task? (e.g. `"agent": "DocRewriterAgent"`)

### ✅ 2. `originFile`  
> Which file prompted this task? (e.g. `"originFile": "strategist.md"`)

### ✅ 3. `context`  
```json
"context": {
  "memoryRef": "ParsedMemoryMap.json",
  "spanTraceRef": "span_trace.log",
  "generatedBy": "Strategist",
  "blessStatus": "unblessed"
}
```

- `memoryRef` → Links to specific memory context if applicable  
- `spanTraceRef` → Logs where this action was routed  
- `generatedBy` → Who initiated this (agent or user)  
- `blessStatus` → `"unblessed"`, `"staged"`, `"blessed"`

### ✅ 4. `requires`  
Optional: Add task dependencies:
```json
"requires": ["TASK:validate-all-docs", "TASK:update-version-log"]
```

### ✅ 5. `routeTo`  
Optional: Where does the output go?
```json
"routeTo": "/outputs/staged/DocRewriterAgent"
```

---

## 🧠 BONUS STRUCTURES

Add a master task manifest:
- `task_index.json`  
- Auto-generated list of all `task_id`s with status + lastTouched timestamp  
- Agents can use it to fetch work

---

## 📂 OUTPUT STRUCTURE EXAMPLE

```json
{
  "task_id": "doc-rewrite-002",
  "description": "Rewrite README.md using updated ParsedMemoryMap",
  "agent": "DocRewriterAgent",
  "originFile": "README.md",
  "status": "in_progress",
  "priority": "high",
  "created_by": "founder",
  "timestamp": "2025-06-04T00:12:00Z",
  "context": {
    "memoryRef": "ParsedMemoryMap.json",
    "spanTraceRef": "span_trace.log",
    "generatedBy": "Strategist",
    "blessStatus": "unblessed"
  },
  "requires": ["TASK:memory-parse-complete"],
  "routeTo": "/outputs/staged/DocRewriterAgent"
}
```

---

## ✅ HANDOFF INSTRUCTIONS

Give this upgrade list to your devs and say:  
> “These logs are now runtime triggers. Update all existing task logs to follow this schema. Each one should be self-contained, memory-aware, and ready to execute or bless with no human clarification needed.”