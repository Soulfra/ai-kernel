# DOCUMENTATION CONSOLIDATION PRD

## Goal
Unify documentation planning, agent output logging, and memory-backed updates into one dynamic, modular documentation system.

## Phase 1: Agent Compatibility Layer
- Ensure each doc is editable by DocRewriterAgent.js
- Route expanded docs into DocExpansionRouter.json
- Use ParsedMemoryMap.json to track chat-log extracted info

## Phase 2: Kernel Integration
- Every doc links to:
  - AgentMeta.json
  - BlessingManifest.json
  - PromptFlowMap.json
- Finalized outputs are versioned and stored under versioning/

## Phase 3: Expansion Architecture
- Max ~250 lines per document
- After that, route into:
  - {doc}_sub1.md
  - {doc}_examples.md

## Dependencies
- DocRewriterAgent
- validateDocLength.js
- docLinker.js
# 📚 DOCUMENTATION CONSOLIDATION PRD — CLARITY KERNEL

This PRD defines how the Clarity Kernel’s documentation system will expand, route, validate, and reflect the internal memory of the runtime — with no recursion and no content loss.

It exists to unify:
- Agent-generated outputs
- Memory-sourced rewrites
- Blessed exports
- Dynamic document growth beyond static limits

---

## 🎯 Goal

To build a **modular, expandable, self-validating documentation system** that grows cleanly as the kernel evolves. All docs should remain under 250 lines unless routed, and no doc should drift from its origin or blessing state.

---

## 🧩 Phase 1: Agent Compatibility Layer

- Ensure every `.md` file can be edited by `DocRewriterAgent.js`
- Each doc must be listed in `ParsedMemoryMap.json` with a known source
- When logs or chat history reference a doc, extract into structured memory
- Use `MemoryParserAgent.js` to regularly update `ParsedMemoryMap.json`

---

## 🧠 Phase 2: Kernel Integration

Every doc must explicitly reference:

- `AgentMeta.json` → so agents know how to interact with the doc
- `BlessingManifest.json` → to record whether it’s safe to export
- `PromptFlowMap.json` → to clarify its upstream chain
- `documentation_versions.json` → for version and hash tracking

Docs should validate against:
- Line limits
- Structural format (section headings, hash anchors, etc.)
- Output source (agent-generated, memory-suggested, or manual)

---

## 🧱 Phase 3: Expansion Architecture

Any doc exceeding ~250 lines must be routed into subdocs and declared in `DocExpansionRouter.json`.

Examples:
- `ACTION_PLAN.md` → expands into:
  - `ACTION_PLAN_sub1.md`
  - `ACTION_PLAN_examples.md`

Routing includes:
- Appending expansion links to the parent doc
- Logging the span event in `span_trace.log`
- Updating `documentation_versions.json`

Each subdoc must include:
- `generated_by` metadata
- Agent trace (who expanded it and why)
- Hash of parent doc at time of expansion

---

## 🔄 Rewriter Workflow

1. `DocRewriterAgent.js` is triggered
2. Reads `ParsedMemoryMap.json` and target doc
3. Suggests edits or adds context from memory
4. Writes to `/outputs/staged/DocRewriterAgent/`
5. Validator confirms schema + tone
6. Blesser moves output into `/outputs/blessed/`

Each doc write is timestamped, memory-linked, and listed in the versioning log.

---

## 🔗 Dependencies

- `DocRewriterAgent.js`
- `MemoryParserAgent.js`
- `ParsedMemoryMap.json`
- `DocExpansionRouter.json`
- `validateDocLength.js`
- `docLinker.js`
- `documentation_versions.json`

---

## 📦 Output Criteria

For this system to be “complete”:
- All live docs must be editable, routable, and traceable
- Every blessed doc has version, expansion, and log integrity
- Memory is reflected in docs without introducing drift
- No document shall exceed 250 lines without being routed

Once finalized, this doc system becomes a memory-aware interface between your runtime and any human or agent that needs to collaborate with it.