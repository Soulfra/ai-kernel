# ACTION PLAN

## Objective
Complete a fully working internal orchestration layer for the Clarity Engine using core agents and runtime logic.

## Immediate Goals
- [x] Validate agent structure and PromptFlowMap.json accuracy
- [x] Enable CLI execution using runAgent.js
- [ ] Confirm tone validation logic with validateAllAgents.js
- [ ] Test blessAgent.js flow with successful and fallback outputs
- [ ] Log all output to /logs/AgentRunHistory.json
- [ ] Run MemoryParserAgent on legacy chat logs
- [ ] Route expanded docs into DocExpansionRouter.json as needed

## Agents in Use
- Strategist: proposes actions, rewrites, and chain plans
- CopyAlchemist: tone-driven copywriter agent
- ToneCalibrator: adjusts message flavor based on voice.json
- Validator: confirms schema, structure, tone match
- Blesser: final output validation and export gatekeeper

## CLI Execution Tasks
```bash
node runAgent.js strategist "Propose next 5 agents"
node validateAllAgents.js
node blessAgent.js CopyAlchemist
```

## Milestones
- Kernel blessable with zero output errors
- All agent outputs routed, validated, and stored in memory
- Outputs versioned, logs tracked, and runtime safe for CLI execution

## Notes
Frontend/skin layers will not be introduced until kernel is fully sealed and output paths are locked.
# ⚙️ ACTION PLAN — CLARITY KERNEL RUNTIME

This document defines the active steps to get the Clarity Engine into a sealed, execution-ready state. The goal is to bring every agent online in a stable, non-recursive environment, using the CLI runtime and internal blessing loop.

---

## 🎯 Objective

Build and bless a **fully orchestrated kernel** for internal use — where all agents run cleanly, route through validation, and store their outputs with tone-safe integrity.

Once complete, this becomes a modular runtime platform you (the founder) can use directly, and later pass off to external devs, agents, or UI skins.

---

## 🔁 Immediate Build Steps

- [x] Validate agent structure and `PromptFlowMap.json`
- [x] Enable CLI execution via `runAgent.js`
- [ ] Implement tone validation and structure checks with `validateAllAgents.js`
- [ ] Confirm output blessing via `blessAgent.js`
- [ ] Log all outputs to `/logs/AgentRunHistory.json` with schema + tone status
- [ ] Run `MemoryParserAgent.js` on legacy logs to seed memory
- [ ] Add any long documents to `/DocExpansionRouter.json` once they exceed 250 lines

---

## 🧠 Active Agents

- **Strategist** → suggests agents, rewrites, priorities
- **CopyAlchemist** → generates tone-matched copy
- **ToneCalibrator** → adjusts output based on `voice.json`
- **Validator** → checks output structure + emotional clarity
- **Blesser** → blesses final output and exports to `/blessed/`

---

## 🧪 CLI Test Flow

```bash
node runAgent.js strategist "What agents are missing?"
node validateAllAgents.js
node blessAgent.js CopyAlchemist
```

Run this chain for all agents and log failures in `/logs/`.

---

## ✅ Completion Milestones

- [ ] All core agents validated and returning schema-safe outputs
- [ ] Validator + Blesser logic confirmed on at least 3 flows
- [ ] All CLI commands usable without manual patching
- [ ] Span traces logged for every executed doc (`span_trace.log`)
- [ ] `/outputs/blessed/` populated with at least 5 validated artifacts

---

## 🛑 What This Plan Does *Not* Include

- No skin/frontend/UX layers — those get routed post-blessing
- No agent recursion — all suggestions are read-only
- No integration with external APIs until full blessing layer is sealed

---

## 🧭 Notes + Expansion Hooks

- If this doc exceeds 250 lines, route to `ACTION_PLAN_sub1.md`
- Blessing status tracked in `documentation_versions.json`
- Memory traces and source logs linked via `ParsedMemoryMap.json`