# 🧾 LOGGING PLAN — CLARITY ENGINE RUNTIME

This plan outlines the full logging strategy for the Clarity Kernel. Every agent run, validation attempt, blessing decision, document rewrite, and memory access should be captured for future reference, agent trust, and runtime visibility.

---

## 🎯 Purpose

To ensure full traceability of:
- Agent behavior
- Output quality
- Tone compliance
- Recursive failure prevention
- Blessing history

Logs act as a forensic tool for audits, debugging, agent health, and emotional memory tracking.

---

## 📂 Key Logging Files + Surfaces

| File | What It Stores |
|------|----------------|
| `/logs/AgentRunHistory.json` | Every agent input/output + validation result |
| `/logs/MemoryTrace.log` | Source logs and memory parse events |
| `/span_trace.log` | Document rewrites, doc expansions, agent triggers |
| `/reports/validation_coverage.json` | Validator test coverage + failures |
| `/ParsedMemoryMap.json` | Parsed prompt context from chat logs or system events |

---

## 🧠 What Gets Logged

- `agent`: Name of the triggered agent
- `input`: Original prompt or user request
- `output`: Returned string, object, or message
- `tone_pass`: Whether the tone matches `voice.json` rules
- `schema_pass`: Whether the output conforms to the agent schema
- `blessed`: Boolean indicator if output was successfully blessed
- `timestamp`: Full ISO timestamp
- `fallback_triggered`: Optional – whether a fallback chain was activated
- `origin`: Manual, strategist-suggested, or memory-parsed

---

## ✅ Log Entry Example

```json
{
  "agent": "CopyAlchemist",
  "input": "Write a confident flirty one-liner",
  "output": "Tell me what you want, and I’ll make sure it sounds better.",
  "tone_pass": true,
  "schema_pass": true,
  "blessed": true,
  "origin": "strategist",
  "timestamp": "2025-06-04T19:34:12Z"
}
```

---

## 🛑 Critical Requirements

- All logs must be append-only (no mutation of past entries)
- If tone or schema fails, that must be recorded in the same log file
- All blessed outputs must reference their log entry
- Agent runs without logs should be treated as invalid

---

## 📈 Traceability Rules

Every blessed file must:
- Reference the log ID of its originating run
- Be hash-verified before export
- Link to `documentation_versions.json` if it’s a doc

Blessed outputs without matching logs should be flagged by `Validator.js`.

---

## 🧪 Span Logging (Doc Expansion)

If a document is rewritten or split:
- Log the original file, agent triggered, and subdoc target in `span_trace.log`
- Example:

```
[2025-06-04T20:01Z] DocRewriterAgent → LOGGING_PLAN.md exceeded 250 lines → created LOGGING_PLAN_sub1.md
```

---

## 🔮 Future Logging Features

- Voice routing history: log every time a different `voice.json` is used
- Public bless logs: output registry of all blessed exports
- Doc rewriter explainability: log why it rewrote something
- Memory stitching: track which chat log memory influenced each doc line

---

## 🧷 Linked Memory Components

All logs should optionally reference:
- `ParsedMemoryMap.json`
- `DocExpansionRouter.json`
- `OrchestrationMap.json`

This enables cross-document clarity and agent accountability.