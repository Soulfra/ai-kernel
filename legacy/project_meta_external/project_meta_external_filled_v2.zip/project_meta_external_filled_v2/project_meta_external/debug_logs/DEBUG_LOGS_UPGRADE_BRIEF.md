# 🛠 DEBUG LOGS UPGRADE BRIEF  
### For: `/debug_logs/` folder in Clarity Kernel

---

## 🎯 PURPOSE

The `/debug_logs/` folder is where runtime errors, orchestration faults, test failures, and agent crashes should be surfaced — but in a structured, readable, and traceable format.

This allows devs or agents to:
- Triage broken execution paths
- Replay failed spans
- Trace invalid agent results
- Capture misrouted doc rewrites or bless attempts

---

## 🧩 FILE TYPES EXPECTED

| File | Purpose |
|------|---------|
| `orchestration_debug.log` | Orchestrator or runtime loop crashes |
| `DEBUG_LOG_jest_*.md` | Specific test runner output with stack traces |
| `agent_debug_*.log` | Failed agent runs, especially on malformed input |
| `parser_failures.md` | Issues parsing chat logs, memory, or malformed `.md` |

---

## ✅ STRUCTURE EXPECTATIONS

### 🔢 1. Timestamped Headers

Each error should start with:
```
[2025-06-04T20:13:52Z] :: AGENT_FAIL: CopyAlchemist
```

### 📄 2. File Context
```
source: runAgent.js
input: "Rewrite this to be more sincere"
```

### ⚠️ 3. Error Body (sanitized)
Show either stack trace or normalized summary:
```
error: "TypeError: Cannot read properties of undefined (reading 'toFixed')"
```

### 🧠 4. Recovery Suggestions
```
suggestion: "Add a fallback check in tone-calibrator.js to guard against undefined tone_tag"
```

---

## 🧭 TRACE LINKING

If possible, reference:
- `span_trace.log`
- `ParsedMemoryMap.json`
- Related `task_id` if the debug event broke during task execution

---

## 🧪 Suggested File Name Patterns

Use clear and timestamped naming:
- `agent_debug_ToneCalibrator_2025-06-04.log`
- `parser_failures_memorymap_2025-06-02.md`
- `orchestration_debug_loop_error_2025-06-03.log`

---

## 🧠 SMART AGENT INTEGRATION

Future agents like `DebugReviewerAgent.js` or `CrashTracer.js` should be able to:
- Parse this folder
- Surface the most common failure patterns
- Write issues into `/task_logs/` as new structured tasks
- Suggest fixes or run fallback flows

---

## 🧷 NEXT ACTIONS

- Refactor existing logs in this folder to match the above structure
- Route active debug traces into here using `runAgent.js` and orchestration tools
- Use the debug folder as a *trusted record of failure*, not just a dump zone

This is your kernel’s black box — make it readable, routable, and reversible.