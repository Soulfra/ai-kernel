# 📊 REPORTS LAYER UPGRADE BRIEF  
### For: `/reports/` folder in Clarity Kernel

---

## 🎯 PURPOSE

Ensure all diagnostic and telemetry reports in the `/reports/` folder are:
- Log-validating and agent-routable
- Human-readable and machine-parseable
- Capable of confirming memory, expansion, or runtime health
- Structured to support export, auditing, or failure review

---

## 🗂️ TARGET FILES

| File | Use |
|------|-----|
| `task-report.json` | Report on current kernel tasks, statuses, and health |
| `telemetry_test_report.json` | Trace performance or heartbeat-style runtime |
| `documentation_test_report.json` | Ensure docs pass tone, schema, and structure checks |
| `dataFlow_test_report.json` | Trace how data moves through the kernel stack |
| `dependency-analysis-*.json` | Runtime and file-level dependency mapping |
| `dependency-validation-*.json` | Validate that all links/paths/files match schema or link policy |

---

## ✅ UPGRADE CHECKLIST

Each report should include:

### 🔁 1. `reportId` + `generatedAt`
```json
"reportId": "telemetry_2025_06_03",
"generatedAt": "2025-06-03T11:48:25.935Z"
```

### 📚 2. `summary` block
```json
"summary": {
  "status": "clean",
  "issuesFound": 0,
  "warnings": [],
  "notes": []
}
```

### 📦 3. `linkedTasks`
Every report should include references to the task(s) it is validating.
```json
"linkedTasks": ["TASK:validate-docs", "TASK:agent-log-span-check"]
```

### 📈 4. `reportScope`
Define the report scope clearly:
- `"scope": "docs"`  
- `"scope": "memory"`  
- `"scope": "agent validation"`  
- `"scope": "runtime dataflow"`

### 💡 5. `recommendedNextSteps`
```json
"recommendedNextSteps": [
  "Re-run MemoryParserAgent on legacy logs",
  "Bless all docs passing validation",
  "Update `documentation_versions.json`"
]
```

---

## 🧠 OPTIONAL ENHANCEMENTS

- Include a `"linkedMemory"` object referencing `ParsedMemoryMap.json`
- Include `"spanLogRefs"` from `span_trace.log` for doc-specific reports
- Include `"blessed"` status: `true/false`
- Generate `.md` versions of reports for public or UI presentation

---

## ✅ REPORT STRUCTURE EXAMPLE

```json
{
  "reportId": "documentation_test_2025_06_03",
  "generatedAt": "2025-06-03T11:48:25.935Z",
  "summary": {
    "status": "warnings",
    "issuesFound": 3,
    "warnings": ["Missing tone compliance in 2 docs"],
    "notes": ["Agent schema outdated in AGENT_REGISTRY.md"]
  },
  "linkedTasks": ["TASK:doc-validate", "TASK:bless-readme"],
  "reportScope": "docs",
  "recommendedNextSteps": [
    "Rewrite AGENT_REGISTRY.md to match validator rules",
    "Re-run tone calibrator",
    "Log rewriter span to `span_trace.log`"
  ]
}
```

---

## 🛠 NEXT ACTIONS

Drop this `.md` file into `/reports/` and task your dev/agent team to:
- Patch all current reports with this structure
- Add metadata needed for agent routing + system traceability
- Ensure `.json` and (if needed) `.md` report mirrors are always generated

This becomes your live diagnostics layer for agent truth, tone, structure, and memory correctness.

---

Built for the runtime. Validated by agents. Blessed by you.