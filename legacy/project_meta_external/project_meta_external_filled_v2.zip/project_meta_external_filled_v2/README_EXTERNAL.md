# 🌐 External Project Meta Guide — Clarity Kernel

This folder provides external developers, reviewers, and system integrators with everything needed to understand, contribute to, or extend the Clarity Kernel runtime.

It contains execution-ready, version-controlled documentation connected directly to the runtime layer — including agent plans, tone validation logic, expansion routes, and memory-augmented document flows.

---

## 📦 What's Included

- ✅ `ACTION_PLAN.md` — Live roadmap and execution chain
- ✅ `FINALIZATION_PLAN.md` — Criteria for blessing and sealing the system
- ✅ `LOGGING_PLAN.md` — What gets logged, why, and how to trace failures
- ✅ `DOCUMENTATION_CONSOLIDATION_PRD.md` — How docs expand safely over time
- ✅ `ParsedMemoryMap.json` — Memory extracted from past conversations or logs
- ✅ `DocExpansionRouter.json` — Routes docs past 250-line overflow
- ✅ `OrchestrationMap.json` — Maps agent-file interactions
- ✅ `documentation_versions.json` — Tracks which docs were blessed and when

---

## 🔁 Runtime Compatibility

This folder assumes the following agent runtime already exists:

- `runAgent.js` → Runs any core agent with provided prompt
- `blessAgent.js` → Approves safe output and moves it to `/outputs/blessed/`
- `validateAllAgents.js` → Batch-checks all agents for schema/tone compliance
- `MemoryParserAgent.js` → Parses log files or `.md` discussions
- `DocRewriterAgent.js` → Updates documents based on structured memory

All agents are non-recursive, tone-bound, and follow clear schema contracts.

---

## 🧠 Use Cases for This Folder

- **Onboarding new builders**: Point them here before touching agent code
- **Frontend/dev team interface**: Treat this as the source of blessed prompts, docs, and system flows
- **Runtime auditing**: Use logs + span traces to explain any chain of agent decisions
- **Document expansion**: Fork this folder and route subdocs using `DocExpansionRouter.json`
- **No-code systems**: This folder works as-is in environments like Supabase, Replit, and Claude-compatible pipelines

---

## 📎 Standards

All documents must:
- Be capped at ~250 lines unless routed
- Include expansion logic via `DocExpansionRouter.json`
- Reference their memory source if rewritten
- Be listed in `documentation_versions.json` if blessed
- Never self-edit or recursively mutate other files

---

## 📤 Export Rules

To export this folder as a production-ready runtime layer:
1. Run `validateAllAgents.js`
2. Run `blessAgent.js` on all docs
3. Zip only `/plans/`, `/logs/`, `/versioning/`, and `/outputs/blessed/`
4. Remove `/outputs/staged/` unless debugging is needed

---

## ✅ What This *Is*

- A modular clarity OS
- A documentation kernel with schema-awareness
- A version-controlled prompt system
- A bridge between agents and real-world deployment

## ❌ What This Is *Not*

- A full frontend layer (that lives elsewhere)
- A product itself — this is the backend tone interface
- A throwaway planning folder — this stack runs your agents

---

Welcome to the external edge of your clarity runtime.